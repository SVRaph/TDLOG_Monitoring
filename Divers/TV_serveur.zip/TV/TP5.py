#!/usr/bin/python
#encoding: latin1

# ce script gère qui le serveur web
# il y a 4 pages : 
#  - index.html     : crée le formulaire html à partir du fichier xml et génère les dicos  
#  - vote.html      : incrémente le vote, et stocke le couple ip:date
#  - resultats.html : affiche le résultat
#  - resultats_bruts.txt : page fournissant le résultat par le script client


import web
import datetime
import xml.dom.minidom as xdom
import operator


#on utilise deux conteneurs globaux
#  - une liste des différents programmes
#  - un dico pour stocker les dates de connection des différentes ip
#on n'effectue actuellement aucune sauvegarde  
etat_des_progs=[]
etat_des_progs_sort=[]
dico_ip={}
date_ini_progs=[datetime.datetime(2000,1,1)]
date_resultats=[datetime.datetime(2000,1,1)]
results=[]

#un type d'Exception
class ParametreNonValide(Exception):
    def __init__(self,s):
        self.mess=s
    def __str__(self):
        return ("***ERREUR : Parametre "+self.mess+" non reconnu")

#classe enregistrant les différents paramètres caractérisant un programme télé en particulier
class Programme:
    def __init__(self,d="",c="",deb="18:00",dur="9:00"):
        try:
            self.description=d
            self.chaine=c
            #les heures début et fin sont définies en min après 18h
            #on évite ainsi des pb comme les émissions commençant après minuit
            self.debut=((int(deb[0:2])+6) %24)*60+int(deb[3:5])
            duree=int(dur[0])*60+int(dur[2:4])
            self.fin=self.debut+duree
            self.vote=0
        except Exception,ex:
            print "***ERREUR : Probleme intialisation Programme",ex
    def iscompatible(self,p):
        return ((self.fin<p.debut)|(p.fin<self.debut))
      
results=[Programme(),Programme()]

#on définie l'en-tête et l'en-queue standard
standard_title='''
<html>

<head>
	<title>KI :// R&eacute;seau des r&eacute;sidences :: La t&eacute;l&eacute;</title>

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
	<meta http-equiv="Content-Style-Type" content="text/css"/>
	<meta name="keywords" content="ENPC,Ponts,ParisTech,Clubinfo,KI,Meunier,Perronet,R&eacute;seau des r&eacute;sidences,La t&eacute;l&eacute;"/>

	<link rel="stylesheet" type="text/css" href="static/style.css"/>
</head>

<body>

<table class="full" style="width:100%;height:100%;">
	<tr style="height:100px;">
		<td style="height:100px;width:200px;background:url('static/c1.png') repeat-y right;"></td>
		<td style="height:100px;width:17px;background:url('static/c2l1.png') bottom no-repeat #006650;"></td>
		<td id="header" style="height:100px;background:url('static/c3l1.png') bottom repeat-x #006650;"><div>Clubinfo de l'&Eacute;cole des Ponts ParisTech</div><i>P 401 - clubinfo@clubinfo.enpc.fr</i></td>
	</tr>
	<tr>
		<td id="menu" style="width:200px;background:url('static/c1.png') repeat-y right;padding-top:60px;"></td>
		<td style="width:17px;background:url('static/c2l2.png') left repeat-y #fff;"></td>
		<td id="corpus">
			       
<h1>R&eacute;seau des r&eacute;sidences :: La t&eacute;l&eacute;</h1>
'''
standard_end='''
<hr/>
<center><i>clubinfo@clubinfo.enpc.fr - ENPC KI<br/>Refonte du site par H&egravel&egravene Dieumegard et Kevin Obrejan (KI'011) : Septembre 2009</i></center>

</table>

<img src="static/logo.png" alt="static/logo.png" style="position:absolute;left:0px;top:0px;border:0px;"/>
<img src="static/c4l1.png" alt="" style="position:absolute;top:0px;right:0px;"/>

</body>
</html>
'''

# remplace é,è,à dans s par leurs équivalents en html
def str2html(s):
    dico={"é":"&eacute","è":"&egrave","à":"&agrave"}
    for c in dico:
        s=s.replace(c,dico[c])
    return s
# méthode pour récupérer la valeur du champs st dans le fichier xml dans un bon format pour l'html
def getTag(p,st):
    r=p.getElementsByTagName(st)[0].firstChild.data
    r=r.encode('latin1')
    r=str2html(r)
    return r

# Page d'index laisse le choix entre un vers la page clubinfo.org et un lien vers la page accueil.html pour voter
class index:
    def GET(self):
        s='<p> Que cherches-tu ? : <br> <a href="http://clubinfo.enpc.org">le site du KI ?</a> <br> ou <br> <a href="/accueil.html">les votes pour la t&eacutel&eacute ?</a> <p>'
        ip=web.ctx.ip
        if str(ip)=='195.221.194.14':
            s+='<br><br>Actuellement tu utilises le proxy tu ne peux donc pas voter'
        else:
            s+='<br><br>Actuellement tu n''utilises pas le proxy tu ne peux donc pas te connecter &agrave internet'     
        return standard_title+s+standard_end


#La page d'accueil doit afficher un formulaire
#on utilise un formulaire de type checkbox pour laisser à l'utilisateur la possibilité de choisir plusieurs programmes (même s'ils sont incompatibles)
#on génère le formulaire à partir de la liste etat_des_progs qu'il faut donc initialiser la première fois à partir du fichier xml source
#par rapport à la méthode consistant à lire le fichier à chaque fois cette méthode à l'avantage d'être plus fiable/efficace mais le formulaire ne s'adapte pas en temps réel 
class accueil:
    def GET(self):
        source='sondage.xml'
        l_base='<input type="checkbox" name="%d" value="1">%s</input><br>\n'
        form='<h2>Fomulaire</h2><form action="vote.html" method="get">\n'
        try:
            #lecture du fichier et initialisation
            #on n'effectue cette étape qu'une seule fois par jour
            now=datetime.datetime.today()
            if ((now.date()) != (date_ini_progs[0].date())):
                date_ini_progs[0]=now
                doc=xdom.parse(source)
                for n in xrange(len(etat_des_progs)):
                    etat_des_progs.pop()
                dico_ip.clear()
                for p in doc.getElementsByTagName('programme'):
                    description=getTag(p,'description')
                    chaine=getTag(p,'chaine')
                    debut=getTag(p,'debut')
                    duree=getTag(p,'duree')
                    etat_des_progs.append(Programme(description,chaine,debut,duree))
            #creation des differentes lignes du formulaire
            indice=0
            for p in etat_des_progs: 
                form+=l_base % (indice,p.description)
                indice+=1
            #finalisation
            form+='<input type="submit" name="Envoyer"></form>\n'
            form+='<a href="/resultats.html">Voir les resultats</a>\n'
        except Exception,ex:
            print ex
            return "Probl&egraveme de cr&eacuteation du formulaire"
        return standard_title+form+standard_end

#cette page vérifie la validité du vote (1 seul vote par ip toutes les 4h...), l'enregistre
#et affiche une page de confirmation
class vote:
    def GET(self):
        ip=web.ctx.ip
        now=datetime.datetime.today()
        deltat=datetime.timedelta(hours=4)#ou voir index
        if dico_ip.has_key(ip):
            if (dico_ip[ip]+deltat > now):
                return standard_title+"Vous avez d&eacuteja vot&eacute aujourd'hui"+standard_end
        dico=web.input()
        vote="<br>"
        try:
            for c in dico:
                if c=="Envoyer":
                    pass
                else:
                    val=int(c)
                    if val+1>len(etat_des_progs):
                        raise ParametreNonValide("trop grand")
                    etat_des_progs[val].vote+=1
                    vote+=etat_des_progs[val].description+"<br>"
                    dico_ip.update({ip:now}) 
        except Exception,ex:
            #principalement si la value n'est pas un entier ou est trop grande
            print ex
            return "Vote invalide"    
        
        #affichage de la page
        res="Vous avez vot&eacute : %s<br>Merci de votre participation, votre vote a bien &eacutet&eacute pris en compte<br><a href=\"/resultats.html\">Voir les r&eacutesultats</a><br>" % (vote)
        return standard_title+res+standard_end

#on affiche les résultats, actuellement les ip des votants sont visibles
#on sélectionne d'abord le programme ayant reçu le plus de vote puis le deuxième programme compatible
#je reconnais toutefois que cette méthode d'optimisation est discutable mais efficace
 
def prepare_resultats():
    #on prépare le calcule des résultats on ne réalise qu'une fois toutes les 5 minutes
    #pour ne pas s'exposer à des problème de surcharge du serveur (tri de la liste)
    #on effectue une recopie pour ne pas modifier la variable globale 
    #afin de conserver l'ordre d'affichage des lignes dans les autres pages
    now=datetime.datetime.today()
    deltat=datetime.timedelta(minutes=5)
    if (date_resultats[0]+deltat > now):
        return
    date_resultats[0]=now

    progs_sort=etat_des_progs[:]
    progs_sort.reverse()#pour la stabilité du tri
    progs_sort.sort(key=operator.attrgetter('vote'))
    progs_sort.reverse()      
    p1=progs_sort[0]
    p2=Programme()
    b=True
    for x in progs_sort:
        if (x.vote>0)&(b)&p1.iscompatible(x):
            p2=x
            b=False
    results[0]=p1
    results[1]=p2

class resultats:
    def GET(self):
        prepare_resultats()
        res="<br><h3>Liste des r&eacutesultats :</h3><br>"
        for x in etat_des_progs:
            res+=str(x.vote)+" : "+x.description+"<br>"

        res+="<br><h3>Programmation de ce soir :</h3><br>"
        res+=str(results[0].vote)+" : "+results[0].description+"<br>"
        res+=str(results[1].vote)+" : "+results[1].description+"<br>"

        res+="<br><h3>Liste des votants :</h3><br>"
        for a in dico_ip:
            res+=str(a)+" : "+str(dico_ip[a])+"<br>"
        return standard_title+res+standard_end

#on souhaite renvoyer simplement:
#time-chaine/time-chaine...
#afin de se connecter avec un autre script et lancer le script correspondant à code à time (avec la même convention time en min après 18h
class resultats_bruts:
    def GET(self):
        prepare_resultats()
        return (str(results[0].debut)+"-"+results[0].chaine+"/"+str(results[1].debut)+"-"+results[1].chaine)
               
if __name__=='__main__':
    urls = (
    	"/index.html","index",
        "/accueil.html","accueil",
        "/vote.html","vote",
        "/resultats.html","resultats",
        "/resultats_bruts.txt","resultats_bruts"
        )
    webapp=web.application(urls,globals())
    webapp.run()
